import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-remove-inventory',
  templateUrl: './remove-inventory.component.html',
  styleUrls: ['./remove-inventory.component.css']
})
export class RemoveInventoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
