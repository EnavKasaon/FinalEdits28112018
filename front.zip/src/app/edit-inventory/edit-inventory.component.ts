import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-inventory',
  templateUrl: './edit-inventory.component.html',
  styleUrls: ['./edit-inventory.component.css']
})
export class EditInventoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
