import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agora',
  templateUrl: './agora.component.html',
  styleUrls: ['./agora.component.css']
})
export class AgoraComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
