import { Injectable } from "@angular/core";



@Injectable()
export class appSettings {

    //For Dev Env
    // baseUrl: string = "http://localhost:4200";
  //ServerApp/BackAHApp
    serverBaseUrl: string = "http://localhost:50427";
     
    
}

