import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-remove-files',
  templateUrl: './remove-files.component.html',
  styleUrls: ['./remove-files.component.css']
})
export class RemoveFilesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
