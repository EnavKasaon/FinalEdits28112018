export enum SupplierType {
    donor =1 ,
    regular = 2
}