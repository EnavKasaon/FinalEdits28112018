export enum VolunteerType {
    holidays =1 ,
    Permanent = 2
}