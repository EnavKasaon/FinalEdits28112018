export class Task {
    task_id: number;
    task_desc:string;
    task_status:boolean;
}