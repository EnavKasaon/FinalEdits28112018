export class Event {
    event_id: number;
    event_desc:string;
    start_date:Date;
    end_date:Date;
    color: string;
}